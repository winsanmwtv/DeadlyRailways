package ktbkonno.winsanmwtv;

import javax.swing.*;
import java.awt.*;

public class Gameplay extends JFrame {

    Gameplay() {
        add(new GamePanel());
    }
}